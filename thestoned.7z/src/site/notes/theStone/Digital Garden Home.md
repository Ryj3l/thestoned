---
{"dg-publish":true,"permalink":"/the-stone/digital-garden-home/","tags":["gardenEntry"]}
---



# [[theStone/Digital Garden Home\|Digital Garden Home]]

## 📝 Notes

### Linux
| File                                                                                                                   | Note Title                                     | Link                                                                                                                   |
| ---------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| [[theStone/3. Main/Playbooks/AD Groups for Sudo Rules\|AD Groups for Sudo Rules]]                                   | AD Groups for Sudo Rules                       | [[theStone/3. Main/Playbooks/AD Groups for Sudo Rules\|AD Groups for Sudo Rules]]                                   |
| [[theStone/3. Main/Playbooks/Add SSH Keys to AD User Attributes\|Add SSH Keys to AD User Attributes]]               | Add SSH Keys to AD User Attributes             | [[theStone/3. Main/Playbooks/Add SSH Keys to AD User Attributes\|Add SSH Keys to AD User Attributes]]               |
| [[theStone/3. Main/Playbooks/Debian AD Integration\|Debian AD Integration]]                                         | Debian AD Integration                          | [[theStone/3. Main/Playbooks/Debian AD Integration\|Debian AD Integration]]                                         |
| [[theStone/3. Main/Linux Active Directory Integration Explanation\|Linux Active Directory Integration Explanation]] | Linux Active Directory Integration Explanation | [[theStone/3. Main/Linux Active Directory Integration Explanation\|Linux Active Directory Integration Explanation]] |
| [[theStone/3. Main/Nginx and No-IP for DNS\|Nginx and No-IP for DNS]]                                               | Nginx and No-IP for DNS                        | [[theStone/3. Main/Nginx and No-IP for DNS\|Nginx and No-IP for DNS]]                                               |
| [[theStone/3. Main/Playbooks/Oracle Linux AD Integration\|Oracle Linux AD Integration]]                             | Oracle Linux AD Integration                    | [[theStone/3. Main/Playbooks/Oracle Linux AD Integration\|Oracle Linux AD Integration]]                             |
| [[theStone/3. Main/PAM Tips & Tricks\|PAM Tips & Tricks]]                                                           | PAM Tips & Tricks                              | [[theStone/3. Main/PAM Tips & Tricks\|PAM Tips & Tricks]]                                                           |
| [[theStone/3. Main/Securely Manage Linux in AD\|Securely Manage Linux in AD]]                                       | Securely Manage Linux in AD                    | [[theStone/3. Main/Securely Manage Linux in AD\|Securely Manage Linux in AD]]                                       |
| [[theStone/3. Main/Playbooks/Setting up Kerberos in Linux\|Setting up Kerberos in Linux]]                           | Setting up Kerberos in Linux                   | [[theStone/3. Main/Playbooks/Setting up Kerberos in Linux\|Setting up Kerberos in Linux]]                           |

{ .block-language-dataview}

## Related Ideas [[]] 
- 



