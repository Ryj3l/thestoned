exports.ALL_NOTE_SETTINGS= [
    "dgHomeLink",
    "dgPassFrontmatter",
    "dgShowBacklinks",
    "dgShowLocalGraph",
    "dgShowInlineTitle",
    "dgShowFileTree",
    "dgEnableSearch",
    "dgShowToc",
    "dgLinkPreview",
    "dgShowTags"
];